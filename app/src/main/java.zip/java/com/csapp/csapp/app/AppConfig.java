package com.csapp.csapp.app;

/**
 * Created by Shubhi on 4/12/2016.
 */
public class AppConfig {
    public static String URL_START="http://uniqueenterprises.in/amisha/csapp/";
    public static String URL_LOGIN=URL_START+"login.php";
    public static String URL_REGISTER=URL_START+"register.php";
    public static String URL_STUDENT_REGISTER=URL_START+"studentregister.php";
    public static String URL_STUDENT_LOGIN=URL_START+"studentlogin.php";
}
